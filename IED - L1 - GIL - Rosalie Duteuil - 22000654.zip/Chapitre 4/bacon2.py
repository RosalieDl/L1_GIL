# ********************************************************/
# Nom ......... : bacon2.py
# Rôle ........ : Version modifiée de bacon.py, à utiliser dans l'archive GIL-TP4-exercice-4.2.zip
# Auteur ...... : Rosalie Duteuil
# Version ..... : V1.0 du 19/07/2024
# Licence ..... : réalisé dans le cadre du cours Gestion d'Identité en Ligne
# Usage ....... : Pour exécuter : python3 bacon2.py
# ********************************************************/

import csv
import sys

from definition import StackFrontier, QueueFrontier
from definition import  Node

# Collection d'IDs d'individus (person_ids)
names = {}

# Un Dictionnaire avec les attributs : name, birth, movies (une collection de (movie_ids))
people = {}

# Transforme (movie_ids) en un Dictionnaire avec les attributs : title, year, stars (Une collection de (person_ids))
movies = {}


def load_data(directory):
    """
    On charge les fichiers CSV en mémoire (environ 1,5 Go est nécessaire)
    """
    # les individus
    with open(f"{directory}/people.csv", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            people[row["id"]] = {
                "name": row["name"],
                "birth": row["birth"],
                "movies": set()
            }
            if row["name"].lower() not in names:
                names[row["name"].lower()] = {row["id"]}
            else:
                names[row["name"].lower()].add(row["id"])

    # les films
    with open(f"{directory}/movies.csv", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            movies[row["id"]] = {
                "title": row["title"],
                "year": row["year"],
                "stars": set()
            }

    # les acteurs
    with open(f"{directory}/stars.csv", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            try:
                people[row["person_id"]]["movies"].add(row["movie_id"])
                movies[row["movie_id"]]["stars"].add(row["person_id"])
            except KeyError:
                pass

# Correction issue du Wiki des étudiants
def shortest_path(source, target):
    """
    Retourne la liste la plus courte des paires (movie_id, person_id)
    qui connecte la source à la cible (target)

    Si ce n'est pas possible, retourne "none"
    """
    solution = list()

    initial = Node(state=source, parent=None, action=None)
    frontier = QueueFrontier()
    frontier.add(initial)
    explored = set()
    i = 0
    while True:

        # Plus rien dans frontier, c'est qu'il n'y a pas de lien
        if frontier.empty():
            return None

        node = frontier.remove()
        # print("\n\nNode in= ",node, ' i=', i)

        if node.state == target:
            while node.parent is not None:
                pid, mid = node.state, node.action
                solution.append((mid, pid))
                node = node.parent
            solution.reverse()
            return solution

        explored.add(node)
        children = neighbors_for_person(node.state)
        for child in children:
            child_node = Node(state=child[1], action=child[0],parent=node)
            frontier.add(child_node)
            if child_node.state == target:
                while child_node.parent is not None:
                    pid, mid = child_node.state, child_node.action
                    solution.append((mid, pid))
                    child_node = child_node.parent
                solution.reverse()
                return solution


def person_id_for_name(name):
    """
    Retourne l'identifiant IMDB pour un individu donné (name),
    résout les ambiguités si nécessaire
    """
    person_ids = list(names.get(name.lower(), set()))
    if len(person_ids) == 0:
        return None
    elif len(person_ids) > 1:
        print(f"Quel '{name}'?")
        for person_id in person_ids:
            person = people[person_id]
            name = person["name"]
            birth = person["birth"]
            print(f"ID: {person_id}, Name: {name}, Birth: {birth}")
        try:
            person_id = input("Entrez l'ID de l'Acteur choisi: ")
            if person_id in person_ids:
                return person_id
        except ValueError:
            pass
        return None
    else:
        return person_ids[0]


def neighbors_for_person(person_id):
    """
    retourne les paires (movie_id, person_id) pour les individus qui ont joué avec une personne donnée (person_id)
    
    """
    movie_ids = people[person_id]["movies"]
    neighbors = set()
    for movie_id in movie_ids:
        for person_id in movies[movie_id]["stars"]:
            neighbors.add((movie_id, person_id))
    return neighbors

def load():
    if len(sys.argv) > 2:
        sys.exit("Usage: python degrees.py [directory]")
    directory = sys.argv[1] if len(sys.argv) == 2 else "IMDB"
    
    # on imprime
    print("Chargement des Données IMDB...")
    load_data(directory)
    print("Données Chargées en Mémoire.")

def run():  
    source = person_id_for_name(input("Nom Complet de l'Acteur 1: "))
    if source is None:
        print("Acteur non trouvé")
        return
        # sys.exit("Acteur non Trouvé.")
    target = person_id_for_name(input("Nom Complet de l'Acteur 2: "))
    if target is None:
        print("Acteur non trouvé")
        return
        # sys.exit("Acteur non Trouvé.")
        
    path = shortest_path(source, target)
    
    if path is None:
        print("Fichiers non Trouvés")
    else:
        degrees = len(path)
        print(f"{degrees} degrés de séparation.")
        path = [(None, source)] + path
        for i in range(degrees):
            person1 = people[path[i][1]]["name"]
            person2 = people[path[i + 1][1]]["name"]
            movie = movies[path[i + 1][0]]["title"]
            print(f"{i + 1}: {person1} et {person2} se sont connus dans {movie}")
            
def main() :
    load()
    while input("Continuer (o/n) ? ") == "o" :
        run()
    
if __name__ == "__main__":
    main()
    