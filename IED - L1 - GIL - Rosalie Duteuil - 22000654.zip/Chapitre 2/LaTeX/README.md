# LaTeX_P8

Ce projet est un modèle de document LaTeX utilisable pour les devoirs de
l'IED de l'Université Paris 8.

Ce modèle est très largement inspiré du travail d'un collègue : https://github.com/amartos/TexIEDP8. Merci à lui.


## Prérequis

Le projet nécessite évidemment les utilitaires `git` et `make`. Veillez à ce
qu'ils soient installés sur vos systèmes. 

La police `Linux Libertine` est définie par défaut ; vous pouvez la modifier dans le fichier `src/format.tex`.

Les packages prérequis et leurs options sont listés dans le fichier `src/requirements.tex`. Le moteur utilisé est xelatex, et biber pour la bibliographie.
Pour une installation simple des prérequis, sur une distribution GNU/Linux basée
Debian (comme Ubuntu), installez les packages `texlive-full` et `biber`:

```
sudo apt install git make texlive-full biber
```

## Installation

Pour commencer un devoir, clonez le projet :

```
git clone https://github.com/RosalieDl/LaTeX_P8 nom_du_répertoire
```

Vous pouvez ensuite retirer l'adresse du dépôt distant si vous pensez cela nécessaire - 
cela empêchera de le mettre à jour (à moins de redéfinir l'adresse):

```
cd nom_du_répertoire
git remote rm origin
```

## Utilisation

### Les métadonnées

Les données globales du document sont à définir dans `metadata.tex` : nom et n° étudiant, année scolaire, matière et intitulé du chapitre...  
Il est également possible d'y définir le langage utilisé par défaut pour les listings. 


### Le contenu

Le contenu du devoir doit se trouver dans un ou plusieurs fichiers `.tex`
dans le dossier `/document`. Ce dossier est scanné automatiquement lors de la
compilation avec le `makefile`. Attention, l'ordre d'ajout est basé sur le nom
du fichier. N'utilisez pas d'espaces dans les noms de fichiers, préférez les tirets bas.  
Un exemple de chapitre, et de page d'annexe, sont à retrouver dans le dossier en question.

Les **images** à ajouter via les commandes personnalisées (voir section suivante)
sont à placer dans le dossier `/images`, et les **codes sources** dans `/code`.  
La **bibliographie** doit être au format biblatex dans le fichier `biblio.bib`. Un
excellent gestionnaire de bibliographie est [Zotero](https://www.zotero.org/).

Pour activer ou désactiver la **table des matières**, il suffit de commenter ou décommenter la ligne correspondante dans le fichier `main.tex`. Pour activer la table des figures, décommenter les lignes concernées dans `src/toc.tex`

### La compilation

Pour compiler entièrement votre document (incluant TDM et bibliographie), utilisez `make full`. 
Une compilation simple est possible avec la commande `make`.

Si vous ne souhaitez pas utiliser le `Makefile`, modifiez le fichier `src/content.tex` 
en incluant les fichiers de votre document et lancez les commandes:

```
mkdir -p build
xelatex -output-directory=build --jobname="main" main.tex
biber build/main
xelatex -output-directory=build --jobname="main" main.tex
xelatex -output-directory=build --jobname="main" main.tex
```
Le document PDF final est `build/main.pdf`. Le document `main.pdf` situé dans le dossier racine du projet n'est qu'un lien symbolique vers ce fichier.


## Rôles des fichiers

`biblio.bib`      : contient la bibliographie  
`metadata.tex`	  : données générales du document  
`main.tex`        : spécifie les fichiers tex à inclure dans le document (par ex. table des matières et bibliographie)

`src/requirements` : packages  
`src/format`       : paramétrage des titres etc  
`src/titlepage`    : formatage de la page de titre  
`src/toc`          : table des matières (et éventuellement des figures)  
`src/bibliography` : paramètres de la bibliographie  
`src/codeblocks` : options des listings (code)  
`src/commands`  : commandes utilisateur (code, images, ...)
`src/environments` : environnements tcolor box personnalisés  


## Commandes personnalisées
	
* **code** - formate du texte comme du code. Par défaut langage bash (donc juste noir et blanc mais police mono), sinon préciser→ `\code[python]{texte qu'on veut au format code}`
* **codeblock** - insère un bloc de code. Est un environnement. Par défaut pas de numérotation des lignes, et langage est celui du document (lstset dans metadata.tex). On peut passer optionnellement des paramètres à lstlisting →  `\begin[numers=left]{codeblock} Du code ... \end{codeblock}`
* **codefile**  - affiche un code source rangé dans le dossier /code. Dans les options on a par ex language=python, ou encore title=une légende. Chemin du fichier est relatif à /code. → `\codefile[title=Code 1.b, fonction de tri]{script.py}`
* **simplefig** -  pour les figures → `\simplefig{légende}{figure}`. La figure en elle-même ressemble à quelque chose comme `\includegraphics[scale=0.5]{chemin_de_l'image}`. 
* **imgcaption** - récupérée dans /images, on peut mettre ou non une légende (si non, laisser {} vide)→ `\image[options]{légende}{image.jpg}`. Note : peut être utilisée dans les minipages, donc dans un environnement graybox. 
* **screenshot** - même principe, mais format paysage, et incompatibles minipages/grayb `\screenshot[options]{légende}{capture.png}`
* **screenshotsm** - pour screenshot de téléphone, peut en mettre 2 côte à côte ; hors graybox. `\screenshot[options]{légende}{img1.jpg}{img2.jpg}`, avec chemin2 optionnel. 
* **starchapter** - ajoute chapitre non numéroté (texte et tdm) → `\starchapter{titre}`
* **starsection** et starsubsection - même chose.
* **addbookmark** - ie un hyperlien pour le pdf → `\addbookmark{type}{niveau}{texte}`, avec type qqchose comme toc ou titlepage, et niveau au choix chapter, section etc... 
* **petitre** : ajoute un petit titre (gras, indenté), sans numérotation particulière.

## Environnements tcolorbox

* **question** : fond bleu, bandeau de titre qui dit «Enoncé» par défaut, sinon préciser `[title=whatever]`
* **réponse** : fond gris, pas de titre par défaut
* **remarque** : texte grisé, aligné à droite, barre verticale à gauche. Possible de mettre un titre ou pas. 

Remarques : 
Pour les commandes qui utilisent des figures (screeshotsm notamment), parfois elles se barrent à perpet quoi qu'on fasse ; dans ce cas mettre `\clearpage` pour que la suite du document leur passe pas devant.
## Licence

Ce projet est sous licence GPL v3.
